"""
NEXUS - Daily Assistant Desktop
Python overlay app with floating right-side icon bar
Python 3.8+ with tkinter (included in Windows Python)
"""

import tkinter as tk
from tkinter import font as tkfont
import threading
import time
import math
import json
import os
import sys
import subprocess
from datetime import datetime, date, timedelta
import urllib.request
import urllib.parse

# ──────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────
DATA_FILE = os.path.join(os.path.expanduser("~"), ".nexus_data.json")

COLORS = {
    "bg":        "#050810",
    "surface":   "#0d1117",
    "surface2":  "#161b27",
    "border":    "#1e2535",
    "accent":    "#00f5c4",
    "accent2":   "#7b5cf0",
    "accent3":   "#ff6b35",
    "warning":   "#ffd235",
    "text":      "#e8eaf0",
    "muted":     "#5a6080",
    "danger":    "#ff4444",
    "success":   "#00c896",
}

PANEL_WIDTH  = 520
ICON_BAR_W   = 58
ICON_SIZE    = 38

ICONS_DEF = [
    ("clock",  "🕐", "Clock"),
    ("weather","🌤", "Weather"),
    ("todo",   "✅", "Tasks"),
    ("pomo",   "🍅", "Pomodoro"),
    ("calc",   "🔢", "Calculator"),
    ("notes",  "📝", "Notes"),
    ("habits", "🔥", "Habits"),
    ("quote",  "💬", "Quote"),
]

QUOTES = [
    ("Discipline is the bridge between goals and accomplishment.", "Jim Rohn"),
    ("Success is going from failure to failure without losing your enthusiasm.", "Winston Churchill"),
    ("Your time is limited. Don't waste it living someone else's life.", "Steve Jobs"),
    ("The only way to do great work is to love what you do.", "Steve Jobs"),
    ("Everything you can imagine is real.", "Pablo Picasso"),
    ("What does not kill you makes you stronger.", "Nietzsche"),
    ("A journey of a thousand miles begins with a single step.", "Lao Tzu"),
    ("Creativity is intelligence having fun.", "Albert Einstein"),
    ("Be the change you wish to see in the world.", "Gandhi"),
    ("There is only one way to avoid criticism: do nothing.", "Aristotle"),
    ("Great things start with small decisions.", "Anonymous"),
    ("Every day is a new chance to change.", "Anonymous"),
]

HABITS_DEFAULT = [
    {"emoji": "💧", "name": "Drink 2L of water"},
    {"emoji": "🏃", "name": "Exercise"},
    {"emoji": "📚", "name": "Read 20 minutes"},
    {"emoji": "🧘", "name": "Meditate"},
    {"emoji": "😴", "name": "Sleep 8h"},
]


# ──────────────────────────────────────────────
# PERSISTENCE
# ──────────────────────────────────────────────
def load_data():
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except:
        return {}

def save_data(data):
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except:
        pass

# ──────────────────────────────────────────────
# AUTOSTART (Windows & Linux)
# ──────────────────────────────────────────────
def setup_autostart():
    app_path = os.path.abspath(sys.argv[0])
    if sys.platform == "win32":
        import winreg
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Run",
            0, winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(key, "NexusApp", 0, winreg.REG_SZ,
                          f'"{sys.executable}" "{app_path}"')
        winreg.CloseKey(key)
    elif sys.platform.startswith("linux"):
        autostart_dir = os.path.expanduser("~/.config/autostart")
        os.makedirs(autostart_dir, exist_ok=True)
        desktop = f"""[Desktop Entry]
Type=Application
Name=Nexus
Exec={sys.executable} {app_path}
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
"""
        with open(os.path.join(autostart_dir, "nexus.desktop"), "w") as f:
            f.write(desktop)
    elif sys.platform == "darwin":
        plist = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.nexus.app</string>
  <key>ProgramArguments</key>
  <array><string>{sys.executable}</string><string>{app_path}</string></array>
  <key>RunAtLoad</key><true/>
</dict></plist>"""
        plist_path = os.path.expanduser("~/Library/LaunchAgents/com.nexus.app.plist")
        with open(plist_path, "w") as f:
            f.write(plist)
        os.system(f"launchctl load {plist_path}")

def remove_autostart():
    if sys.platform == "win32":
        try:
            import winreg
            key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Run",
                0, winreg.KEY_SET_VALUE
            )
            winreg.DeleteValue(key, "NexusApp")
            winreg.CloseKey(key)
        except:
            pass


# ══════════════════════════════════════════════
#  MAIN APPLICATION
# ══════════════════════════════════════════════
class NexusApp:
    def __init__(self):
        self.data = load_data()
        self.current_panel = None
        self.panel_visible = False
        self.weather_cache = None
        self.pomo_state = {
            "running": False, "mode": "focus",
            "time": 25 * 60, "sessions": 0, "total": 25 * 60
        }
        self._pomo_after = None
        self._clock_after = None
        import random
        self._quote_idx = random.randint(0, len(QUOTES)-1)

        self._build_root()
        self._build_icon_bar()
        self._build_panel()
        self._start_clock()

        # Show clock by default
        self.show_panel("clock")

        self.root.mainloop()

    # ─────────────────────────────────
    # ROOT WINDOW (transparent overlay)
    # ─────────────────────────────────
    def _build_root(self):
        # ── Main window: content panel ──
        self.root = tk.Tk()
        self.root.title("NEXUS")
        self.root.configure(bg=COLORS["bg"])
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.97)

        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self._sw = sw
        self._sh = sh

        # Panel hidden initially (positioned off-screen to the right)
        self.root.geometry(f"{PANEL_WIDTH}x{sh}+{sw}+0")

        # ── Secondary window: floating icon bar ──
        self.bar_win = tk.Toplevel(self.root)
        self.bar_win.title("")
        self.bar_win.overrideredirect(True)
        self.bar_win.attributes("-topmost", True)
        self.bar_win.attributes("-alpha", 0.92)
        self.bar_win.geometry(f"{ICON_BAR_W}x{sh}+{sw - ICON_BAR_W}+0")
        self.bar_win.configure(bg="#0a0f1a")

    # ─────────────────────────────────
    # ICON BAR (right side)
    # ─────────────────────────────────
    def _build_icon_bar(self):
        self.bar_frame = tk.Frame(
            self.bar_win, bg="#0a0f1a",
            width=ICON_BAR_W, highlightthickness=0
        )
        self.bar_frame.place(x=0, y=0, relwidth=1.0, relheight=1.0)

        # Left separator
        sep = tk.Frame(self.bar_frame, bg=COLORS["border"], width=1)
        sep.place(x=0, y=0, relheight=1.0, width=1)

        sh = self.root.winfo_screenheight()
        n = len(ICONS_DEF)
        block_h = n * (ICON_SIZE + 10) + 20
        start_y = (sh - block_h) // 2

        self.icon_buttons = {}
        for i, (key, emoji, label) in enumerate(ICONS_DEF):
            y = start_y + i * (ICON_SIZE + 10)
            btn = tk.Label(
                self.bar_frame,
                text=emoji,
                font=("Segoe UI Emoji", 18),
                bg="#0a0f1a",
                fg=COLORS["muted"],
                cursor="hand2",
                width=2,
            )
            btn.place(x=4, y=y, width=ICON_BAR_W-8, height=ICON_SIZE)
            btn.bind("<Button-1>", lambda e, k=key: self.toggle_panel(k))
            btn.bind("<Enter>",    lambda e, b=btn: self._icon_hover(b, True))
            btn.bind("<Leave>",    lambda e, b=btn: self._icon_hover(b, False))
            self.icon_buttons[key] = btn

        # Quit button at the bottom
        quit_btn = tk.Label(
            self.bar_frame, text="✕",
            font=("Segoe UI", 13, "bold"),
            bg="#0a0f1a", fg=COLORS["danger"],
            cursor="hand2"
        )
        quit_btn.place(x=4, y=sh-44, width=ICON_BAR_W-8, height=36)
        quit_btn.bind("<Button-1>", lambda e: self.root.destroy())

        # Bind leave on the icon bar to close panel when mouse exits
        self.bar_frame.bind("<Leave>", self._on_bar_leave)
        self.bar_frame.bind("<Enter>", self._on_bar_enter)
        self.bar_win.bind("<Leave>", self._on_bar_leave)
        self.bar_win.bind("<Enter>", self._on_bar_enter)
        self._mouse_in_panel = False
        self._leave_after = None

    def _icon_hover(self, btn, enter):
        key = [k for k, b in self.icon_buttons.items() if b is btn]
        active = (key[0] == self.current_panel) if key else False
        if enter:
            btn.configure(fg=COLORS["accent"], bg=COLORS["surface2"])
        else:
            btn.configure(
                fg=COLORS["accent"] if active else COLORS["muted"],
                bg=COLORS["surface"] if active else "#0a0f1a"
            )

    def _on_bar_enter(self, e=None):
        self._mouse_in_panel = True
        if self._leave_after:
            self.root.after_cancel(self._leave_after)
            self._leave_after = None

    def _on_bar_leave(self, e=None):
        self._mouse_in_panel = False
        if self._leave_after:
            self.root.after_cancel(self._leave_after)
        self._leave_after = self.root.after(300, self._check_close_panel)

    def _on_panel_enter(self, e=None):
        self._mouse_in_panel = True
        if self._leave_after:
            self.root.after_cancel(self._leave_after)
            self._leave_after = None

    def _on_panel_leave(self, e=None):
        self._mouse_in_panel = False
        if self._leave_after:
            self.root.after_cancel(self._leave_after)
        self._leave_after = self.root.after(300, self._check_close_panel)

    def _check_close_panel(self):
        self._leave_after = None
        if not self._mouse_in_panel and self.panel_visible:
            self._hide_panel()

    def _set_active_icon(self, key):
        for k, btn in self.icon_buttons.items():
            btn.configure(
                fg=COLORS["accent"] if k == key else COLORS["muted"],
                bg=COLORS["surface"] if k == key else "#0a0f1a"
            )

    # ─────────────────────────────────
    # PANEL CONTAINER
    # ─────────────────────────────────
    def _build_panel(self):
        # Panel IS the root window itself
        self.panel = tk.Frame(self.root, bg=COLORS["bg"], highlightthickness=0)
        self.panel.place(x=0, y=0, relwidth=1.0, relheight=1.0)

        # Right border
        sep = tk.Frame(self.panel, bg=COLORS["border"], width=1)
        sep.place(relx=1.0, y=0, relheight=1.0, width=1, anchor="ne")

        self.content_frame = tk.Frame(self.panel, bg=COLORS["bg"])
        self.content_frame.place(x=0, y=0, relwidth=1.0, relheight=1.0)

        # Close panel when mouse leaves
        self.root.bind("<Leave>", self._on_panel_leave)
        self.root.bind("<Enter>", self._on_panel_enter)

    # ─────────────────────────────────
    # TOGGLE / SHOW PANEL
    # ─────────────────────────────────
    def toggle_panel(self, key):
        if self.current_panel == key and self.panel_visible:
            self._hide_panel()
        else:
            self.show_panel(key)

    def _hide_panel(self):
        # Move root window off screen — only icon bar stays visible
        self.root.geometry(f"{PANEL_WIDTH}x{self._sh}+{self._sw}+0")
        self.panel_visible = False
        self.current_panel = None
        self._set_active_icon(None)

    def show_panel(self, key):
        self.current_panel = key
        self.panel_visible = True
        # Slide panel in just left of the icon bar
        x = self._sw - PANEL_WIDTH - ICON_BAR_W
        self.root.geometry(f"{PANEL_WIDTH}x{self._sh}+{x}+0")
        self._set_active_icon(key)
        for w in self.content_frame.winfo_children():
            w.destroy()
        builders = {
            "clock":   self._build_clock,
            "weather": self._build_weather,
            "todo":    self._build_todo,
            "pomo":    self._build_pomodoro,
            "calc":    self._build_calculator,
            "notes":   self._build_notes,
            "habits":  self._build_habits,
            "quote":   self._build_quote,
        }
        if key in builders:
            builders[key]()

    # ─────────────────────────────────
    # UI HELPERS
    # ─────────────────────────────────
    def _scrollable(self, parent):
        canvas = tk.Canvas(parent, bg=COLORS["bg"], highlightthickness=0, bd=0)
        scrollbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        frame = tk.Frame(canvas, bg=COLORS["bg"])
        frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind("<MouseWheel>", lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))
        return frame

    def _header(self, parent, emoji, title):
        hf = tk.Frame(parent, bg=COLORS["surface"], height=64)
        hf.pack(fill="x")
        hf.pack_propagate(False)
        dot = tk.Label(hf, text="●", font=("Segoe UI", 8),
                       fg=COLORS["accent"], bg=COLORS["surface"])
        dot.place(x=20, y=26)
        lbl = tk.Label(hf, text=f"  {emoji}  {title}",
                       font=("Segoe UI", 13, "bold"),
                       fg=COLORS["text"], bg=COLORS["surface"])
        lbl.place(x=32, rely=0.5, anchor="w")
        sep = tk.Frame(parent, bg=COLORS["border"], height=1)
        sep.pack(fill="x")

    def _card(self, parent, padx=16, pady=12):
        outer = tk.Frame(parent, bg=COLORS["surface"],
                         highlightbackground=COLORS["border"],
                         highlightthickness=1)
        outer.pack(fill="x", padx=16, pady=6)
        inner = tk.Frame(outer, bg=COLORS["surface"])
        inner.pack(fill="x", padx=padx, pady=pady)
        return inner

    def _label(self, parent, text, size=12, bold=False, color=None, **kw):
        return tk.Label(
            parent, text=text,
            font=("Segoe UI", size, "bold" if bold else "normal"),
            fg=color or COLORS["text"],
            bg=parent.cget("bg"),
            **kw
        )

    def _btn(self, parent, text, cmd, color=None, fg=None, width=8, pady=6):
        c = color or COLORS["accent"]
        f = fg or COLORS["bg"]
        b = tk.Button(
            parent, text=text, command=cmd,
            font=("Segoe UI", 10, "bold"),
            bg=c, fg=f,
            activebackground=COLORS["surface2"],
            activeforeground=COLORS["text"],
            relief="flat", bd=0,
            cursor="hand2",
            padx=12, pady=pady,
            width=width,
        )
        b.bind("<Enter>", lambda e: b.configure(bg=self._lighten(c)))
        b.bind("<Leave>", lambda e: b.configure(bg=c))
        return b

    def _lighten(self, hex_color):
        try:
            r = int(hex_color[1:3], 16); g = int(hex_color[3:5], 16); b = int(hex_color[5:7], 16)
            r = min(255, r + 30); g = min(255, g + 30); b = min(255, b + 30)
            return f"#{r:02x}{g:02x}{b:02x}"
        except:
            return hex_color

    def _entry(self, parent, **kw):
        e = tk.Entry(
            parent,
            font=("Segoe UI", 11),
            bg=COLORS["surface2"],
            fg=COLORS["text"],
            insertbackground=COLORS["accent"],
            relief="flat",
            highlightthickness=1,
            highlightbackground=COLORS["border"],
            highlightcolor=COLORS["accent"],
            **kw
        )
        return e

    # ══════════════════════════════════
    # PANEL: CLOCK
    # ══════════════════════════════════
    def _build_clock(self):
        p = self.content_frame
        self._header(p, "🕐", "Clock & Date")

        center = tk.Frame(p, bg=COLORS["bg"])
        center.pack(fill="both", expand=True)

        # Canvas for analog clock
        self._clock_canvas = tk.Canvas(
            center, width=240, height=240,
            bg=COLORS["bg"], highlightthickness=0
        )
        self._clock_canvas.pack(pady=30)

        self._clock_time_lbl = self._label(
            center, "", size=42, bold=True, color=COLORS["accent"]
        )
        self._clock_time_lbl.pack()

        self._clock_date_lbl = self._label(
            center, "", size=12, color=COLORS["muted"]
        )
        self._clock_date_lbl.pack(pady=4)

        self._clock_day_lbl = self._label(
            center, "", size=16, bold=True
        )
        self._clock_day_lbl.pack()

        self._draw_clock_face()
        self._update_clock_display()

    def _draw_clock_face(self):
        c = self._clock_canvas
        cx, cy, r = 120, 120, 105
        c.delete("all")
        # Outer circle
        c.create_oval(cx-r-8, cy-r-8, cx+r+8, cy+r+8,
                      outline=COLORS["border"], width=2)
        c.create_oval(cx-r, cy-r, cx+r, cy+r,
                      outline=COLORS["surface2"], width=8, fill=COLORS["surface"])
        # Tick marks
        for i in range(60):
            angle = math.radians(i * 6 - 90)
            if i % 5 == 0:
                r1, r2 = r - 4, r - 18
                color = COLORS["accent"] if i % 15 == 0 else COLORS["muted"]
                w = 2 if i % 15 == 0 else 1
            else:
                r1, r2 = r - 4, r - 10
                color = COLORS["border"]
                w = 1
            x1 = cx + r1 * math.cos(angle)
            y1 = cy + r1 * math.sin(angle)
            x2 = cx + r2 * math.cos(angle)
            y2 = cy + r2 * math.sin(angle)
            c.create_line(x1, y1, x2, y2, fill=color, width=w)

    def _update_clock_display(self):
        if self.current_panel != "clock":
            return
        now = datetime.now()
        c = self._clock_canvas
        cx, cy, r = 120, 120, 105

        self._draw_clock_face()

        # Hour hand
        h_angle = math.radians((now.hour % 12) * 30 + now.minute * 0.5 - 90)
        hx = cx + (r * 0.5) * math.cos(h_angle)
        hy = cy + (r * 0.5) * math.sin(h_angle)
        c.create_line(cx, cy, hx, hy, fill=COLORS["text"], width=5, capstyle="round")

        # Minute hand
        m_angle = math.radians(now.minute * 6 - 90)
        mx = cx + (r * 0.75) * math.cos(m_angle)
        my = cy + (r * 0.75) * math.sin(m_angle)
        c.create_line(cx, cy, mx, my, fill=COLORS["accent"], width=3, capstyle="round")

        # Second hand
        s_angle = math.radians(now.second * 6 - 90)
        sx = cx + (r * 0.85) * math.cos(s_angle)
        sy = cy + (r * 0.85) * math.sin(s_angle)
        c.create_line(cx, cy, sx, sy, fill=COLORS["accent3"], width=1, capstyle="round")

        # Center dot
        c.create_oval(cx-5, cy-5, cx+5, cy+5, fill=COLORS["accent"], outline="")

        # Labels
        JOURS = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        MOIS  = ["January","February","March","April","May","June",
                 "July","August","September","October","November","December"]

        self._clock_time_lbl.configure(text=now.strftime("%H:%M:%S"))
        self._clock_date_lbl.configure(
            text=f"{now.day} {MOIS[now.month-1]} {now.year}"
        )
        day_idx = now.weekday()
        self._clock_day_lbl.configure(text=JOURS[day_idx])

        self._clock_after = self.root.after(1000, self._update_clock_display)

    def _start_clock(self):
        pass  # handled in _update_clock_display

    # ══════════════════════════════════
    # PANEL: WEATHER
    # ══════════════════════════════════
    def _build_weather(self):
        p = self.content_frame
        self._header(p, "🌤", "Live Weather")

        self._weather_frame = tk.Frame(p, bg=COLORS["bg"])
        self._weather_frame.pack(fill="both", expand=True)

        loading = self._label(
            self._weather_frame,
            "📍 Detecting your location...",
            size=12, color=COLORS["muted"]
        )
        loading.pack(pady=60)

        threading.Thread(target=self._fetch_weather, daemon=True).start()

    def _fetch_weather(self):
        try:
            # Geolocation via IP
            geo_url = "https://ipapi.co/json/"
            req = urllib.request.Request(geo_url, headers={"User-Agent": "NexusApp/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                geo = json.loads(resp.read())

            lat = geo.get("latitude", 48.85)
            lon = geo.get("longitude", 2.35)
            city = geo.get("city", "Your city")

            weather_url = (
                f"https://api.open-meteo.com/v1/forecast"
                f"?latitude={lat}&longitude={lon}"
                f"&current=temperature_2m,apparent_temperature,"
                f"relative_humidity_2m,wind_speed_10m,"
                f"surface_pressure,weather_code"
                f"&wind_speed_unit=kmh"
            )
            with urllib.request.urlopen(weather_url, timeout=5) as resp:
                weather = json.loads(resp.read())

            self.weather_cache = {
                "city": city, "data": weather["current"]
            }
            self.root.after(0, self._display_weather)
        except Exception as e:
            self.root.after(0, lambda: self._weather_error(str(e)))

    def _display_weather(self):
        for w in self._weather_frame.winfo_children():
            w.destroy()

        ICONS_W = {
            0:"☀️",1:"🌤",2:"⛅",3:"☁️",
            45:"🌫",48:"🌫",51:"🌦",53:"🌦",55:"🌧",
            61:"🌧",63:"🌧",65:"🌧",71:"🌨",73:"❄️",75:"❄️",
            80:"🌦",81:"🌧",82:"⛈",95:"⛈",96:"⛈",99:"⛈"
        }
        DESCS = {
            0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",
            45:"Fog",48:"Rime fog",
            51:"Light drizzle",53:"Moderate drizzle",55:"Heavy drizzle",
            61:"Light rain",63:"Moderate rain",65:"Heavy rain",
            71:"Light snow",73:"Moderate snow",75:"Heavy snow",
            80:"Light showers",81:"Showers",82:"Violent showers",
            95:"Thunderstorm",96:"Thunderstorm with hail",99:"Violent thunderstorm"
        }

        c = self.weather_cache["data"]
        code = c.get("weather_code", 0)
        icon = ICONS_W.get(code, "🌡")
        desc = DESCS.get(code, "")

        f = self._weather_frame
        tk.Label(f, text=icon, font=("Segoe UI Emoji", 64),
                 bg=COLORS["bg"]).pack(pady=(30, 5))

        tk.Label(f, text=f"{round(c['temperature_2m'])}°C",
                 font=("Segoe UI", 52, "bold"),
                 fg=COLORS["accent"], bg=COLORS["bg"]).pack()

        tk.Label(f, text=desc,
                 font=("Segoe UI", 13),
                 fg=COLORS["muted"], bg=COLORS["bg"]).pack()

        tk.Label(f, text=self.weather_cache["city"],
                 font=("Segoe UI", 16, "bold"),
                 fg=COLORS["text"], bg=COLORS["bg"]).pack(pady=4)

        # Details
        details = tk.Frame(f, bg=COLORS["surface"])
        details.pack(fill="x", padx=16, pady=20)

        items = [
            ("🌡 Feels like",   f"{round(c['apparent_temperature'])}°"),
            ("💧 Humidity",   f"{c['relative_humidity_2m']}%"),
            ("💨 Wind",       f"{round(c['wind_speed_10m'])} km/h"),
            ("📊 Pressure",   f"{round(c['surface_pressure'])} hPa"),
        ]
        for i, (label, val) in enumerate(items):
            col = i % 2
            row = i // 2
            cell = tk.Frame(details, bg=COLORS["surface"])
            cell.grid(row=row, column=col, padx=16, pady=12, sticky="w")
            tk.Label(cell, text=label, font=("Segoe UI", 10),
                     fg=COLORS["muted"], bg=COLORS["surface"]).pack(anchor="w")
            tk.Label(cell, text=val, font=("Segoe UI", 18, "bold"),
                     fg=COLORS["text"], bg=COLORS["surface"]).pack(anchor="w")

        refresh = self._btn(f, "↺  Refresh", self._refresh_weather,
                            color=COLORS["surface2"], fg=COLORS["accent"])
        refresh.pack(pady=8)

    def _refresh_weather(self):
        for w in self._weather_frame.winfo_children():
            w.destroy()
        loading = self._label(self._weather_frame,
            "📍 Refreshing...", size=12, color=COLORS["muted"])
        loading.pack(pady=60)
        threading.Thread(target=self._fetch_weather, daemon=True).start()

    def _weather_error(self, err):
        for w in self._weather_frame.winfo_children():
            w.destroy()
        self._label(self._weather_frame, "⚠️ Failed to load",
                    size=13, color=COLORS["danger"]).pack(pady=40)
        self._label(self._weather_frame, "Check your internet connection",
                    size=10, color=COLORS["muted"]).pack()
        self._btn(self._weather_frame, "↺ Try again",
                  self._refresh_weather).pack(pady=16)

    # ══════════════════════════════════
    # PANEL: TODO
    # ══════════════════════════════════
    def _build_todo(self):
        p = self.content_frame
        self._header(p, "✅", "Today's Tasks")

        if "todos" not in self.data:
            self.data["todos"] = []

        # Input
        inp_frame = tk.Frame(p, bg=COLORS["bg"])
        inp_frame.pack(fill="x", padx=16, pady=12)

        self._todo_entry = self._entry(inp_frame)
        self._todo_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self._todo_entry.bind("<Return>", lambda e: self._add_todo())

        prio_var = tk.StringVar(value="med")
        self._todo_prio = prio_var
        prio_menu = tk.OptionMenu(inp_frame, prio_var, "high", "med", "low")
        prio_menu.configure(bg=COLORS["surface2"], fg=COLORS["text"],
                            font=("Segoe UI", 9), relief="flat", bd=0,
                            activebackground=COLORS["surface"],
                            highlightthickness=0)
        prio_menu["menu"].configure(bg=COLORS["surface2"], fg=COLORS["text"])
        prio_menu.pack(side="left", padx=6)

        add_btn = self._btn(inp_frame, "+  Add", self._add_todo, width=10)
        add_btn.pack(side="left")

        # Progress
        prog_frame = tk.Frame(p, bg=COLORS["bg"])
        prog_frame.pack(fill="x", padx=16, pady=(0, 8))
        self._todo_prog_lbl = tk.Label(prog_frame, text="0/0 tasks",
            font=("Courier", 10), fg=COLORS["muted"], bg=COLORS["bg"])
        self._todo_prog_lbl.pack(side="right")
        prog_canvas = tk.Canvas(prog_frame, height=4, bg=COLORS["surface2"],
                                highlightthickness=0)
        prog_canvas.pack(fill="x", pady=6)
        self._todo_prog_canvas = prog_canvas
        self._todo_prog_bar_w = 0

        # List
        list_frame = tk.Frame(p, bg=COLORS["bg"])
        list_frame.pack(fill="both", expand=True)
        self._todo_scroll = self._scrollable(list_frame)
        self._render_todos()

    def _render_todos(self):
        for w in self._todo_scroll.winfo_children():
            w.destroy()

        todos = self.data.get("todos", [])
        prio_colors = {"high": COLORS["accent3"], "med": COLORS["warning"], "low": COLORS["accent"]}
        prio_labels = {"high": "Urgent", "med": "Normal", "low": "Low"}

        for i, t in enumerate(todos):
            row = tk.Frame(self._todo_scroll, bg=COLORS["surface"],
                           highlightbackground=COLORS["border"],
                           highlightthickness=1)
            row.pack(fill="x", padx=16, pady=4)
            inner = tk.Frame(row, bg=COLORS["surface"])
            inner.pack(fill="x", padx=12, pady=8)

            # Checkbox
            chk_var = tk.BooleanVar(value=t.get("done", False))
            chk = tk.Checkbutton(
                inner, variable=chk_var, bg=COLORS["surface"],
                fg=COLORS["accent"], activebackground=COLORS["surface"],
                selectcolor=COLORS["surface2"],
                relief="flat", bd=0, cursor="hand2",
                command=lambda idx=i, v=chk_var: self._toggle_todo(idx, v)
            )
            chk.pack(side="left")

            text_color = COLORS["muted"] if t.get("done") else COLORS["text"]
            lbl = tk.Label(inner, text=t["text"],
                           font=("Segoe UI", 11,
                                 "overstrike" if t.get("done") else "normal"),
                           fg=text_color, bg=COLORS["surface"],
                           anchor="w", wraplength=300)
            lbl.pack(side="left", fill="x", expand=True)

            pc = prio_colors.get(t.get("priority","med"), COLORS["muted"])
            tk.Label(inner, text=prio_labels.get(t.get("priority","med"), ""),
                     font=("Segoe UI", 8, "bold"),
                     fg=pc, bg=COLORS["surface"], padx=6, pady=2).pack(side="left", padx=4)

            del_btn = tk.Button(inner, text="✕", command=lambda idx=i: self._del_todo(idx),
                                font=("Segoe UI", 9), bg=COLORS["surface"],
                                fg=COLORS["danger"], relief="flat", bd=0, cursor="hand2")
            del_btn.pack(side="left")

        # Update progress
        done = sum(1 for t in todos if t.get("done"))
        total = len(todos)
        self._todo_prog_lbl.configure(text=f"{done}/{total} tasks")
        self._todo_prog_canvas.update_idletasks()
        w = self._todo_prog_canvas.winfo_width()
        fill = int(w * done / total) if total else 0
        self._todo_prog_canvas.delete("all")
        self._todo_prog_canvas.create_rectangle(0, 0, fill, 4,
            fill=COLORS["accent"], outline="")

    def _add_todo(self):
        text = self._todo_entry.get().strip()
        if not text: return
        self.data.setdefault("todos", []).insert(0, {
            "text": text, "priority": self._todo_prio.get(), "done": False
        })
        save_data(self.data)
        self._todo_entry.delete(0, tk.END)
        self._render_todos()

    def _toggle_todo(self, idx, var):
        self.data["todos"][idx]["done"] = var.get()
        save_data(self.data)
        self._render_todos()

    def _del_todo(self, idx):
        self.data["todos"].pop(idx)
        save_data(self.data)
        self._render_todos()

    # ══════════════════════════════════
    # PANEL: POMODORO
    # ══════════════════════════════════
    def _build_pomodoro(self):
        p = self.content_frame
        self._header(p, "🍅", "Pomodoro")

        center = tk.Frame(p, bg=COLORS["bg"])
        center.pack(fill="both", expand=True)

        TIMES = {"focus": 25*60, "short": 5*60, "long": 15*60}
        CIRC = 2 * math.pi * 90

        # Ring canvas
        self._pomo_canvas = tk.Canvas(center, width=220, height=220,
                                       bg=COLORS["bg"], highlightthickness=0)
        self._pomo_canvas.pack(pady=20)

        self._pomo_time_lbl = tk.Label(center, text="25:00",
            font=("Courier New", 38, "bold"),
            fg=COLORS["text"], bg=COLORS["bg"])
        self._pomo_time_lbl.pack()

        self._pomo_mode_lbl = tk.Label(center, text="FOCUS 🎯",
            font=("Segoe UI", 10, "bold"),
            fg=COLORS["muted"], bg=COLORS["bg"])
        self._pomo_mode_lbl.pack(pady=4)

        # Sessions dots
        self._pomo_dots_frame = tk.Frame(center, bg=COLORS["bg"])
        self._pomo_dots_frame.pack(pady=4)

        # Buttons
        btn_frame = tk.Frame(center, bg=COLORS["bg"])
        btn_frame.pack(pady=12)

        self._btn(btn_frame, "↺", lambda: self._pomo_reset(),
                  color=COLORS["surface2"], fg=COLORS["muted"], width=4).pack(side="left", padx=4)
        self._pomo_start_btn = self._btn(btn_frame, "▶  Start",
                  lambda: self._pomo_toggle(), width=10)
        self._pomo_start_btn.pack(side="left", padx=4)
        self._btn(btn_frame, "⏭", lambda: self._pomo_skip(),
                  color=COLORS["surface2"], fg=COLORS["muted"], width=4).pack(side="left", padx=4)

        # Mode selector
        mode_frame = tk.Frame(center, bg=COLORS["bg"])
        mode_frame.pack(pady=8)
        for mode, label in [("focus","25min Focus"),("short","5min Break"),("long","15min Break")]:
            c_bg = COLORS["surface"] if mode != self.pomo_state["mode"] else COLORS["accent"]
            c_fg = COLORS["text"] if mode != self.pomo_state["mode"] else COLORS["bg"]
            tk.Button(
                mode_frame, text=label,
                command=lambda m=mode: self._pomo_set_mode(m),
                font=("Segoe UI", 9), bg=c_bg, fg=c_fg,
                relief="flat", bd=0, cursor="hand2", padx=10, pady=6
            ).pack(side="left", padx=3)

        self._pomo_circ_total = CIRC
        self._pomo_render()

    def _pomo_render(self):
        s = self.pomo_state
        m = str(s["time"] // 60).zfill(2)
        sc = str(s["time"] % 60).zfill(2)
        try:
            self._pomo_time_lbl.configure(text=f"{m}:{sc}")
        except: return

        mode_labels = {"focus":"FOCUS 🎯", "short":"SHORT BREAK ☕", "long":"LONG BREAK 🧘"}
        mode_colors = {"focus":COLORS["accent"], "short":COLORS["accent2"], "long":COLORS["accent3"]}
        color = mode_colors.get(s["mode"], COLORS["accent"])
        try:
            self._pomo_mode_lbl.configure(text=mode_labels.get(s["mode"],""))
        except: return

        # Anneau
        TIMES = {"focus":25*60, "short":5*60, "long":15*60}
        total = TIMES[s["mode"]]
        progress = (total - s["time"]) / total
        cx, cy, r = 110, 110, 90
        CIRC = 2 * math.pi * r

        try:
            c = self._pomo_canvas
            c.delete("all")
            # Track
            c.create_arc(cx-r, cy-r, cx+r, cy+r,
                         start=90, extent=360,
                         style="arc", outline=COLORS["surface2"], width=10)
            # Progress
            if progress > 0:
                extent = -progress * 360
                c.create_arc(cx-r, cy-r, cx+r, cy+r,
                             start=90, extent=extent,
                             style="arc", outline=color, width=10)
        except: pass

        # Session dots
        try:
            for w in self._pomo_dots_frame.winfo_children():
                w.destroy()
            for i in range(4):
                done_color = COLORS["accent"] if i < s["sessions"] % 4 else COLORS["surface2"]
                tk.Label(self._pomo_dots_frame, text="●",
                         font=("Segoe UI", 10),
                         fg=done_color, bg=COLORS["bg"]).pack(side="left", padx=3)
        except: pass

        try:
            self._pomo_start_btn.configure(
                text="⏸  Pause" if s["running"] else "▶  Start"
            )
        except: pass

    def _pomo_toggle(self):
        s = self.pomo_state
        if s["running"]:
            s["running"] = False
            if self._pomo_after:
                self.root.after_cancel(self._pomo_after)
        else:
            s["running"] = True
            self._pomo_tick()
        self._pomo_render()

    def _pomo_tick(self):
        s = self.pomo_state
        if not s["running"]: return
        s["time"] -= 1
        if s["time"] <= 0:
            s["running"] = False
            if s["mode"] == "focus":
                s["sessions"] += 1
                s["mode"] = "long" if s["sessions"] % 4 == 0 else "short"
            else:
                s["mode"] = "focus"
            TIMES = {"focus":25*60,"short":5*60,"long":15*60}
            s["time"] = TIMES[s["mode"]]
        self._pomo_render()
        if s["running"]:
            self._pomo_after = self.root.after(1000, self._pomo_tick)

    def _pomo_reset(self):
        if self._pomo_after:
            self.root.after_cancel(self._pomo_after)
        self.pomo_state = {
            "running":False,"mode":"focus","time":25*60,"sessions":0,"total":25*60
        }
        self._pomo_render()

    def _pomo_skip(self):
        if self._pomo_after:
            self.root.after_cancel(self._pomo_after)
        s = self.pomo_state
        s["running"] = False
        if s["mode"] == "focus":
            s["sessions"] += 1
            s["mode"] = "long" if s["sessions"] % 4 == 0 else "short"
        else:
            s["mode"] = "focus"
        TIMES = {"focus":25*60,"short":5*60,"long":15*60}
        s["time"] = TIMES[s["mode"]]
        self._pomo_render()

    def _pomo_set_mode(self, mode):
        if self._pomo_after:
            self.root.after_cancel(self._pomo_after)
        TIMES = {"focus":25*60,"short":5*60,"long":15*60}
        self.pomo_state["running"] = False
        self.pomo_state["mode"] = mode
        self.pomo_state["time"] = TIMES[mode]
        self._build_pomodoro()

    # ══════════════════════════════════
    # PANEL: CALCULATOR
    # ══════════════════════════════════
    def _build_calculator(self):
        p = self.content_frame
        self._header(p, "🔢", "Calculator")

        calc_frame = tk.Frame(p, bg=COLORS["bg"])
        calc_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # Display
        disp = tk.Frame(calc_frame, bg=COLORS["surface"],
                        highlightbackground=COLORS["border"],
                        highlightthickness=1)
        disp.pack(fill="x", pady=(0, 12))

        self._calc_expr_var = tk.StringVar(value="")
        tk.Label(disp, textvariable=self._calc_expr_var,
                 font=("Courier New", 10), fg=COLORS["muted"],
                 bg=COLORS["surface"], anchor="e").pack(fill="x", padx=12, pady=(8,0))

        self._calc_disp_var = tk.StringVar(value="0")
        tk.Label(disp, textvariable=self._calc_disp_var,
                 font=("Courier New", 36, "bold"), fg=COLORS["text"],
                 bg=COLORS["surface"], anchor="e").pack(fill="x", padx=12, pady=(0,10))

        self._calc_state = {"disp":"0","expr":"","prev":"","op":"","new":True}

        # Buttons
        btn_grid = tk.Frame(calc_frame, bg=COLORS["bg"])
        btn_grid.pack(fill="both", expand=True)

        buttons = [
            [("C","clear",COLORS["accent3"]), ("±","sign",COLORS["surface2"]),
             ("%","pct",COLORS["surface2"]), ("÷","div",COLORS["accent2"])],
            [("7","7",COLORS["surface"]),("8","8",COLORS["surface"]),
             ("9","9",COLORS["surface"]),("×","mul",COLORS["accent2"])],
            [("4","4",COLORS["surface"]),("5","5",COLORS["surface"]),
             ("6","6",COLORS["surface"]),("−","sub",COLORS["accent2"])],
            [("1","1",COLORS["surface"]),("2","2",COLORS["surface"]),
             ("3","3",COLORS["surface"]),("+","add",COLORS["accent2"])],
            [("0","0",COLORS["surface"],2),(".","dot",COLORS["surface"]),
             ("=","eq",COLORS["accent"])],
        ]

        for r, row in enumerate(buttons):
            col = 0
            for item in row:
                lbl, cmd = item[0], item[1]
                bg = item[2]
                colspan = item[3] if len(item) > 3 else 1
                fg_color = COLORS["bg"] if bg == COLORS["accent"] else COLORS["text"]
                if bg == COLORS["accent2"]:
                    fg_color = COLORS["accent2"]

                btn = tk.Button(
                    btn_grid, text=lbl,
                    font=("Segoe UI", 16, "bold"),
                    bg=bg, fg=fg_color,
                    activebackground=self._lighten(bg),
                    activeforeground=fg_color,
                    relief="flat", bd=0, cursor="hand2",
                    command=lambda c=cmd: self._calc_press(c)
                )
                btn.grid(row=r, column=col, columnspan=colspan,
                         sticky="nsew", padx=3, pady=3, ipady=10)
                col += colspan

        for i in range(5): btn_grid.rowconfigure(i, weight=1)
        for i in range(4): btn_grid.columnconfigure(i, weight=1)

        # Keyboard
        self.root.bind("<Key>", self._calc_key)

    def _calc_key(self, e):
        if self.current_panel != "calc": return
        k = e.char
        if k in "0123456789": self._calc_press(k)
        elif k == ".": self._calc_press("dot")
        elif k == "+": self._calc_press("add")
        elif k in "-−": self._calc_press("sub")
        elif k in "*×": self._calc_press("mul")
        elif k in "/÷": self._calc_press("div")
        elif k in "=\r": self._calc_press("eq")
        elif e.keysym == "Escape": self._calc_press("clear")
        elif e.keysym == "BackSpace":
            s = self._calc_state
            if not s["new"] and len(s["disp"]) > 1:
                s["disp"] = s["disp"][:-1]
            else:
                s["disp"] = "0"
            self._calc_update()

    def _calc_press(self, cmd):
        s = self._calc_state
        if cmd in "0123456789":
            if s["new"]: s["disp"] = cmd; s["new"] = False
            else: s["disp"] = "0" if s["disp"] == "0" else s["disp"]; s["disp"] = (s["disp"] + cmd)[:14]
        elif cmd == "dot":
            if s["new"]: s["disp"] = "0."; s["new"] = False
            elif "." not in s["disp"]: s["disp"] += "."
        elif cmd == "sign":
            try: s["disp"] = str(-float(s["disp"])).rstrip("0").rstrip(".")
            except: pass
        elif cmd == "pct":
            try: s["disp"] = str(float(s["disp"]) / 100)
            except: pass
        elif cmd in ("add","sub","mul","div"):
            if s["prev"] and not s["new"]:
                self._calc_press("eq")
            s["prev"] = s["disp"]
            s["op"] = cmd
            ops = {"add":"+","sub":"−","mul":"×","div":"÷"}
            s["expr"] = s["disp"] + " " + ops[cmd]
            s["new"] = True
        elif cmd == "eq":
            if not s["op"] or not s["prev"]: return
            a, b = float(s["prev"]), float(s["disp"])
            ops = {"add":"+","sub":"−","mul":"×","div":"÷"}
            s["expr"] = f"{s['prev']} {ops[s['op']]} {s['disp']} ="
            try:
                if s["op"] == "add": r = a + b
                elif s["op"] == "sub": r = a - b
                elif s["op"] == "mul": r = a * b
                elif s["op"] == "div":
                    r = "Erreur" if b == 0 else a / b
                if isinstance(r, float):
                    r = round(r, 10)
                    if r == int(r): r = int(r)
                s["disp"] = str(r)
            except: s["disp"] = "Erreur"
            s["prev"] = ""; s["op"] = ""; s["new"] = True
        elif cmd == "clear":
            self._calc_state = {"disp":"0","expr":"","prev":"","op":"","new":True}
        self._calc_update()

    def _calc_update(self):
        s = self._calc_state
        d = s["disp"]
        if len(d) > 12: d = f"{float(d):.4e}"
        try:
            self._calc_disp_var.set(d)
            self._calc_expr_var.set(s["expr"])
        except: pass

    # ══════════════════════════════════
    # PANEL: NOTES
    # ══════════════════════════════════
    def _build_notes(self):
        p = self.content_frame
        self._header(p, "📝", "Notes rapides")

        toolbar = tk.Frame(p, bg=COLORS["bg"])
        toolbar.pack(fill="x", padx=16, pady=8)

        self._notes_saved_lbl = tk.Label(toolbar, text="",
            font=("Segoe UI", 9), fg=COLORS["accent"], bg=COLORS["bg"])
        self._notes_saved_lbl.pack(side="right")

        char_lbl_var = tk.StringVar(value="0 characters")
        self._notes_char_var = char_lbl_var
        tk.Label(toolbar, textvariable=char_lbl_var,
                 font=("Courier", 9), fg=COLORS["muted"], bg=COLORS["bg"]).pack(side="left")

        self._btn(toolbar, "🗑 Clear", self._clear_notes,
                  color=COLORS["surface2"], fg=COLORS["danger"], width=9).pack(side="right", padx=6)

        txt_frame = tk.Frame(p, bg=COLORS["bg"])
        txt_frame.pack(fill="both", expand=True, padx=16, pady=(0,16))

        scrollbar = tk.Scrollbar(txt_frame)
        scrollbar.pack(side="right", fill="y")

        self._notes_txt = tk.Text(
            txt_frame,
            font=("Courier New", 11),
            bg=COLORS["surface2"],
            fg=COLORS["text"],
            insertbackground=COLORS["accent"],
            relief="flat",
            bd=0,
            wrap="word",
            yscrollcommand=scrollbar.set,
            padx=12, pady=12,
            highlightthickness=1,
            highlightbackground=COLORS["border"],
            highlightcolor=COLORS["accent"],
        )
        self._notes_txt.pack(fill="both", expand=True)
        scrollbar.config(command=self._notes_txt.yview)

        saved = self.data.get("notes", "")
        self._notes_txt.insert("1.0", saved)
        self._notes_char_var.set(f"{len(saved)} characters")

        self._notes_save_after = None
        self._notes_txt.bind("<KeyRelease>", self._on_notes_change)

    def _on_notes_change(self, e=None):
        content = self._notes_txt.get("1.0", "end-1c")
        self._notes_char_var.set(f"{len(content)} characters")
        if self._notes_save_after:
            self.root.after_cancel(self._notes_save_after)
        self._notes_save_after = self.root.after(800, self._save_notes)

    def _save_notes(self):
        content = self._notes_txt.get("1.0", "end-1c")
        self.data["notes"] = content
        save_data(self.data)
        try:
            self._notes_saved_lbl.configure(text="✓ Saved")
            self.root.after(2000, lambda: self._notes_saved_lbl.configure(text=""))
        except: pass

    def _clear_notes(self):
        self._notes_txt.delete("1.0", tk.END)
        self.data["notes"] = ""
        save_data(self.data)
        self._notes_char_var.set("0 characters")

    # ══════════════════════════════════
    # PANEL: HABITS
    # ══════════════════════════════════
    def _build_habits(self):
        p = self.content_frame
        self._header(p, "🔥", "Habit Tracker")

        if "habits" not in self.data:
            self.data["habits"] = HABITS_DEFAULT.copy()
        if "habit_days" not in self.data:
            self.data["habit_days"] = {}

        today = date.today()
        self._habit_week = [(today - timedelta(days=i)).isoformat() for i in range(6, -1, -1)]
        JOURS = ["M","T","W","T","F","S","S"]

        scroll_frame = self._scrollable(p)

        # Day headers
        header_row = tk.Frame(scroll_frame, bg=COLORS["bg"])
        header_row.pack(fill="x", padx=16, pady=(8, 4))
        tk.Label(header_row, text="Habit", font=("Segoe UI", 10, "bold"),
                 fg=COLORS["muted"], bg=COLORS["bg"], width=20, anchor="w").pack(side="left")
        for d in self._habit_week:
            day_label = JOURS[date.fromisoformat(d).weekday()]
            is_today = d == today.isoformat()
            tk.Label(header_row, text=day_label,
                     font=("Segoe UI", 9, "bold" if is_today else "normal"),
                     fg=COLORS["accent"] if is_today else COLORS["muted"],
                     bg=COLORS["bg"], width=3).pack(side="left")

        for hi, habit in enumerate(self.data["habits"]):
            row = tk.Frame(scroll_frame, bg=COLORS["surface"],
                           highlightbackground=COLORS["border"],
                           highlightthickness=1)
            row.pack(fill="x", padx=16, pady=5)
            inner = tk.Frame(row, bg=COLORS["surface"])
            inner.pack(fill="x", padx=12, pady=10)

            streak = sum(1 for d in self._habit_week
                        if self.data["habit_days"].get(f"{hi}-{d}"))

            tk.Label(inner, text=habit["emoji"], font=("Segoe UI Emoji", 18),
                     bg=COLORS["surface"]).pack(side="left", padx=(0,8))

            info = tk.Frame(inner, bg=COLORS["surface"])
            info.pack(side="left", fill="x", expand=True)
            tk.Label(info, text=habit["name"], font=("Segoe UI", 11, "bold"),
                     fg=COLORS["text"], bg=COLORS["surface"], anchor="w").pack(anchor="w")
            tk.Label(info, text=f"🔥 {streak} day{'s' if streak>1 else ''} this week",
                     font=("Segoe UI", 9), fg=COLORS["muted"],
                     bg=COLORS["surface"]).pack(anchor="w")

            days_frame = tk.Frame(inner, bg=COLORS["surface"])
            days_frame.pack(side="right")

            for day in self._habit_week:
                key = f"{hi}-{day}"
                done = self.data["habit_days"].get(key, False)
                is_today = day == today.isoformat()
                col = COLORS["accent"] if done else (COLORS["surface2"] if not is_today else COLORS["border"])
                outline = COLORS["accent"] if is_today else COLORS["border"]
                btn = tk.Label(
                    days_frame,
                    text="●" if done else "○",
                    font=("Segoe UI", 14),
                    fg=col, bg=COLORS["surface"],
                    cursor="hand2", padx=2
                )
                btn.pack(side="left")
                btn.bind("<Button-1>",
                    lambda e, k=key, hi=hi: self._toggle_habit(k, hi))

    def _toggle_habit(self, key, hi):
        self.data["habit_days"][key] = not self.data["habit_days"].get(key, False)
        save_data(self.data)
        self._build_habits()

    # ══════════════════════════════════
    # PANEL: QUOTE
    # ══════════════════════════════════
    def _build_quote(self):
        p = self.content_frame
        self._header(p, "💬", "Quote of the Day")

        center = tk.Frame(p, bg=COLORS["bg"])
        center.pack(fill="both", expand=True)

        quote_bg = tk.Frame(center, bg=COLORS["surface"],
                            highlightbackground=COLORS["accent2"],
                            highlightthickness=1)
        quote_bg.pack(fill="x", padx=24, pady=30)

        inner = tk.Frame(quote_bg, bg=COLORS["surface"])
        inner.pack(fill="x", padx=24, pady=24)

        tk.Label(inner, text='"', font=("Georgia", 60),
                 fg=COLORS["accent2"], bg=COLORS["surface"]).pack(anchor="w")

        q_text, q_author = QUOTES[self._quote_idx]
        self._quote_lbl = tk.Label(inner, text=q_text,
                 font=("Georgia", 14, "italic"),
                 fg=COLORS["text"], bg=COLORS["surface"],
                 wraplength=420, justify="left")
        self._quote_lbl.pack(fill="x", pady=8)

        self._quote_auth = tk.Label(inner, text=f"— {q_author}",
                 font=("Segoe UI", 11),
                 fg=COLORS["muted"], bg=COLORS["surface"])
        self._quote_auth.pack(anchor="e", pady=(8,0))

        self._btn(center, "↺  New quote",
                  self._new_quote, width=20).pack(pady=16)

        # Navigation dots
        dots = tk.Frame(center, bg=COLORS["bg"])
        dots.pack()
        for i in range(len(QUOTES)):
            col = COLORS["accent"] if i == self._quote_idx else COLORS["surface2"]
            tk.Label(dots, text="●", font=("Segoe UI", 7),
                     fg=col, bg=COLORS["bg"]).pack(side="left", padx=1)

    def _new_quote(self):
        import random
        self._quote_idx = (self._quote_idx + 1) % len(QUOTES)
        self._build_quote()


# ──────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────
if __name__ == "__main__":
    # Setup autostart on first launch
    first_run = not os.path.exists(DATA_FILE)
    if first_run:
        try:
            setup_autostart()
        except Exception as e:
            pass  # Not critical

    app = NexusApp()
