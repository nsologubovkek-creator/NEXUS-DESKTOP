# 🖥️ NEXUS — Assistant Quotidien Desktop

Application overlay Python qui se colle sur le côté droit de ton écran.

---

## 📦 INSTALLATION (Windows)

### Étape 1 — Installer Python
1. Va sur **https://www.python.org/downloads/**
2. Télécharge Python 3.11 ou plus récent
3. ⚠️ **IMPORTANT** : Coche "Add Python to PATH" pendant l'installation

### Étape 2 — Lancer NEXUS
Double-clique sur **`LANCER_NEXUS.bat`**

C'est tout ! NEXUS se lancera et s'ajoutera automatiquement au démarrage Windows.

---

## 🚀 DÉMARRAGE AUTOMATIQUE

Au premier lancement, NEXUS s'inscrit automatiquement dans le registre Windows pour démarrer avec l'ordinateur.

Pour désactiver le démarrage auto :
- Appuie sur `Win + R` → tape `regedit`
- Va dans : `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run`
- Supprime la clé `NexusApp`

---

## 🎯 FONCTIONNALITÉS

| Icône | Fonction |
|-------|----------|
| 🕐 | **Horloge** — Analogique + numérique en temps réel |
| 🌤 | **Météo** — Température, humidité, vent (via ta position) |
| ✅ | **Tâches** — Avec priorités et barre de progression |
| 🍅 | **Pomodoro** — Timer 25min avec anneau animé |
| 🔢 | **Calculatrice** — Complète, utilisable au clavier |
| 📝 | **Notes** — Auto-sauvegardées localement |
| 🔥 | **Habitudes** — Suivi sur 7 jours de la semaine |
| 💬 | **Citations** — Motivation quotidienne |

---

## 📁 DONNÉES

Toutes tes données sont sauvegardées dans :
```
C:\Users\[TonNom]\.nexus_data.json
```

---

## 🔧 UTILISATION

- **Clique sur une icône** → ouvre le panneau correspondant
- **Reclique sur la même icône** → ferme le panneau
- **✕ tout en bas** → ferme l'application
- L'overlay est toujours au-dessus des autres fenêtres

---

## 💻 COMPATIBILITÉ

- Windows 10/11 ✅
- macOS ✅ (démarrage auto via LaunchAgent)  
- Linux ✅ (démarrage auto via .desktop autostart)

---

*NEXUS v1.0 — Python 3.8+ avec tkinter*
