@echo off
title NEXUS - Installation et lancement
color 0A

echo.
echo  ███╗   ██╗███████╗██╗  ██╗██╗   ██╗███████╗
echo  ████╗  ██║██╔════╝╚██╗██╔╝██║   ██║██╔════╝
echo  ██╔██╗ ██║█████╗   ╚███╔╝ ██║   ██║███████╗
echo  ██║╚██╗██║██╔══╝   ██╔██╗ ██║   ██║╚════██║
echo  ██║ ╚████║███████╗██╔╝ ██╗╚██████╔╝███████║
echo  ╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝
echo.
echo  Assistant Quotidien Desktop
echo  ─────────────────────────────────────────────
echo.

:: Vérifier Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERREUR] Python n'est pas installe !
    echo.
    echo  Telecharge Python sur : https://www.python.org/downloads/
    echo  Coche "Add Python to PATH" pendant l'installation.
    echo.
    pause
    start https://www.python.org/downloads/
    exit /b 1
)

echo  [OK] Python detecte
echo.

:: Vérifier tkinter
python -c "import tkinter" >nul 2>&1
if %errorlevel% neq 0 (
    echo  [INFO] Installation de tkinter...
    pip install tk
)

echo  [OK] tkinter disponible
echo.
echo  Lancement de NEXUS...
echo  (L'application s'ajoutera automatiquement au demarrage Windows)
echo.

:: Lancer l'app
python "%~dp0nexus.py"

if %errorlevel% neq 0 (
    echo.
    echo  [ERREUR] L'application a rencontre une erreur.
    pause
)
